#include <stdio.h>
#include <stdlib.h>
#include "cfg.h"

int main()
{
	printf("X = ");
	scanf_s("%d", &res[0]);
	printf("Y = ");
	scanf_s("%d", &res[1]);
	system("cls");
	print(res,pos);
	getchar(); getchar();
	return 0;
}
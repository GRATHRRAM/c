#include <stdio.h>
#include <stdlib.h>
#include "cfg.h"


void print(const int resolution[1], const int positon[1][10])
{
	int i = 0;
	char* to_print = malloc(resolution[0] + 1);
	
	while (i < resolution[0])
	{
		to_print[i] = '#';
		i++;
	}

	to_print[i] = '\0';

	i = 0;
	while (i < resolution[1])
	{
		printf("%s\n", to_print);
		i++;
	}
	free(to_print);
}
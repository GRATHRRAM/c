int res[1];//0 = x 1 = y
int pos[1][10];

void print(const int resolution[1],const int position[1][10]);
